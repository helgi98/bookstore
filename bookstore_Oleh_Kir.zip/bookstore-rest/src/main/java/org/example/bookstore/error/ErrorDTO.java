package org.example.bookstore.error;

public record ErrorDTO(String message) {

}
