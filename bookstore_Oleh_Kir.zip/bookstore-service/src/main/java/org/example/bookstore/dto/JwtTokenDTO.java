package org.example.bookstore.dto;

public record JwtTokenDTO(String token) {
}
