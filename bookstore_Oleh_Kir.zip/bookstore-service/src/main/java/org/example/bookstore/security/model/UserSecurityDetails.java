package org.example.bookstore.security.model;

public record UserSecurityDetails(String userId, String userName) {
}